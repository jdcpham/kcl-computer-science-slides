package labsSGTsCoursework.lab4;

import net.datastructures.SortedListPriorityQueue;
import net.datastructures.PriorityQueue; 

class TestSLPQ 
	{ 
	    public static void main(String[] args) 
	    { 
	       	int size=100;
	    	PriorityQueue<Integer, Integer> PQ= new SortedListPriorityQueue<Integer, Integer>(); 
	         
	        for(int j=0; j<size; j++) 
	        { 
	            int key = (int) (java.lang.Math.random()*999); 
	            int value = (int) (java.lang.Math.random()*999); 
	            PQ.insert(key, value);   
	            //System.out.println(n);
	        } 
	        for(int j=0; j<size; j++) 
	        	System.out.print(PQ.removeMin()+ " "); 
	      } 
	}