package labsSGTsCoursework.lab4;

class TestUnsortTime 
	{ 
	    public static void main(String[] args) 
	    { 
	       	int size=10000;
	    	UnsortedListPriorityQueue<Integer, Integer> PQ= new UnsortedListPriorityQueue<Integer, Integer>(); 
	    	//Insertion Time
	    	long startTimeInsert = System.currentTimeMillis(); 
	        for(int j=0; j<size; j++) 
	        { 
	            int n = (int)(java.lang.Math.random()*size*10); 
	            PQ.insert(n, n);   
	        } 
	        long stopTimeInsert = System.currentTimeMillis();       
            long elapsedTimeInsert = stopTimeInsert - startTimeInsert;       
            System.out.println("Elapsed Time for Insertion "+ elapsedTimeInsert); 
            // Deletion Time
            long startTimeDelete = System.currentTimeMillis(); 
	        for(int j=0; j<size; j++) 
	        	PQ.removeMin();
	        long stopTimeDelete = System.currentTimeMillis();       
	        long elapsedTimeDelete = stopTimeDelete - startTimeDelete;       
	        System.out.println("Elapsed Time for Deletion "+ elapsedTimeDelete); 
	    } 
	}
