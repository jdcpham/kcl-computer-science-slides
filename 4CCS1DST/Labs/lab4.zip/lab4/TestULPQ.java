package labsSGTsCoursework.lab4;

import net.datastructures.PriorityQueue;

class TestULPQ { 
	    public static void main(String[] args) 
	    { 
	    	int size=100;
	    	PriorityQueue<Integer, Integer> PQ= new UnsortedListPriorityQueue<Integer, Integer>(); 
	         
	        //Insert entries at random into the priority queue PQ
	        for(int j=0; j<size; j++) 
	        { 
	            int key = (int) (java.lang.Math.random()*999); 
	            int value = (int) (java.lang.Math.random()*999); 
	            PQ.insert(key, value);   
	            // System.out.println(n);
	        } 
	        //Remove and display minimum element from the front of the list
	        for(int j=0; j<size; j++) 
	            System.out.print(PQ.removeMin()+ " "); 
	            System.out.println(""); 
	    } 
	}