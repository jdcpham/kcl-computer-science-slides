package labsSGTsCoursework.lab4;

import java.util.Comparator;

import net.datastructures.*;

/** 
 * Realization of a priority queue by means of an unsorted node list
 * 
 * this class has been obtained by modifying the class SortedListPriorityQueue<K,V>
 * develobed by Roberto Tamassia, Michael Goodrich, Eric Zamore
 */

public class UnsortedListPriorityQueue<K,V> implements PriorityQueue<K,V> {
	protected PositionList<Entry<K,V>> entries;
	protected Comparator<K> c;
	protected Position<Entry<K,V>> actionPos; // variable used by subclasses

	/** Inner class for entries */
	protected static class MyEntry<K,V> implements Entry<K,V> {
		protected K k; // key
		protected V v; // value
		public MyEntry(K key, V value) {
			k = key;
			v = value;
		}
		// methods of the Entry interface
		public K getKey() { return k; }
		public V getValue() { return v; }

		// overrides toString, useful for debugging
		public String toString() { return "(" + k  + "," + v + ")"; }

	}
	/** Creates the priority queue with the default comparator. */
	public UnsortedListPriorityQueue () {
		entries = new NodePositionList<Entry<K,V>>();
		c = new DefaultComparator<K>();

	}
	/** Creates the priority queue with the given comparator. */
	public UnsortedListPriorityQueue (Comparator<K> comp) {
		entries = new NodePositionList<Entry<K,V>>();
		c = comp;
	}

	/** Creates the priority queue with the given comparator and list.
	 * The list is assumed to be sorted in nondecreasing order.*/
	public UnsortedListPriorityQueue (PositionList<Entry<K,V>> list, Comparator<K> comp) { 
		entries = list;
		c = comp;
	}

	/** Sets the comparator for this priority queue.
	 * @throws IllegalStateException if priority queue is not empty */
	public void setComparator(Comparator<K> comp) throws IllegalStateException {
		if(!isEmpty())  // this is only allowed if the priority queue is empty
			throw new IllegalStateException("Priority queue is not empty");
		c = comp;
	}

	/** Returns the number of elements in the priority queue. */
	public int size () {return entries.size(); }

	/** Returns whether the priority queue is empty. */
	public boolean isEmpty () { return entries.isEmpty(); }

	/** Returns but does not remove an entry with minimum key. */
	public Entry<K,V> min () throws EmptyPriorityQueueException {
		return findMinPosition().element();
	}
	
	/** an auxiliary private method which finds the position 
	 * in the list with the minimum entry;
	 * this method is used in methods min() and removeMin() 
	 */
	private Position<Entry<K,V>> findMinPosition() throws EmptyPriorityQueueException {
		if (entries.isEmpty())
			throw new EmptyPriorityQueueException("priority queue is empty");
		else
			if (entries.size()==1) return entries.first();
			else {
				Position<Entry<K,V>> curr = entries.first();
				// the first entry is set to be the current minimum element
				K min = curr.element().getKey();  // the current minimum entry
				actionPos = curr;  // the position of the current minimum entry
				for (int i=2; i <= entries.size(); i++) {
					curr=entries.next(curr);
					if (c.compare(min, curr.element().getKey()) > 0) {
						min=curr.element().getKey();
						actionPos = curr;
					}
				}
				return actionPos;
			}		
	}

	/** Inserts a key-value pair and return the entry created. */
	public Entry<K,V> insert (K k, V v) throws InvalidKeyException {
		checkKey(k); // auxiliary key-checking method (could throw exception)
		Entry<K,V> entry = new MyEntry<K,V>(k, v);
		insertEntry(entry);               // auxiliary insertion method
		return entry;
	}

	/** Auxiliary method used for insertion. */
	protected void insertEntry(Entry<K,V> e) {
		entries.addLast(e);
		actionPos = entries.last();  
	}

	/** Removes and returns an entry with minimum key. */
	public Entry<K,V> removeMin() throws EmptyPriorityQueueException {
		return entries.remove(findMinPosition());
	}
	
	/** Determines whether a key is valid. */
	protected boolean checkKey(K key) throws InvalidKeyException {
		boolean result;
		try {		// check if the key can be compared to itself
			result = (c.compare(key,key)==0);
		} catch (ClassCastException e)
		{	throw new InvalidKeyException("key cannot be compared"); }
		return result;
	}

	// overrides toString, useful for debugging
	public String toString() {
		return entries.toString(); 
	}

	
	public static void main(String[] args) {
		PriorityQueue<Integer,String> PQ = new UnsortedListPriorityQueue<Integer,String>();
		PQ.insert(5, "a");
		PQ.insert(3, "b");
		PQ.insert(9, "c");
		PQ.insert(2, "d");
		PQ.insert(8, "e");
		
		System.out.println(PQ); // prints: [(5,a), (3,b), (9,c), (2,d), (8,e)]
		
		while ( !PQ.isEmpty() ) {
			System.out.println( PQ.removeMin() );
		}
		// the entries have been printed in order: (2,d) (3,b) (5,a) (8,e) (9,c)
		
		System.out.println(PQ); // prints: []
	}
}
