package lecture1;

import java.util.ArrayList;
import java.util.List;

public class PuzzleSolver
{
	public static boolean puzzleSolve(int k, List<Object> S, List<Object> U) {
		// returns true if, and only if, sequence S can be extended to length k using 
		// distinct elements from U so that the extended sequence is a correct solution 
		// to a given puzzle;
		// this is a recursive method;

		if ( k == 0 ) {
			return checkSequence(S);
		}
		else {
			for (int i = 0; i < U.size(); i++) {
				S.add(U.remove(i));   // remove the 1st element from U and append it to S
				if ( puzzleSolve(k-1,S,U) ) {
					return true;
				}
				else {
					U.add(i,S.remove(S.size()-1));  // remove the last element from S and add it 
					                              // at the end of U
				}
			}
			// sequence S cannot be extended to a correct solution
			return false;
		}
	}

	private static boolean checkSequence(List<Object> S) {
		// check if the sequence S is a correct solution;
		// return true or false, depending whether S is a correct solution or not
				
		// check if sequence S represents a correct solution
		// for the puzzle  cbb + ba = abc
		int a = (Integer) S.get(0);
		int b = (Integer) S.get(1);
		int c = (Integer) S.get(2);
		if ( (b * 100 + c * 10 + c) + (c * 10 + a) == (a * 100 + c * 10 + b) ) {
			return true;
		}
		else {
			return false;
		}
	}

	public static void main(String [] args) {

		List<Object> S = new ArrayList<Object>();
		List<Object> U = new ArrayList<Object>();
		U.add(6);
		U.add(7);
		U.add(8);
		U.add(9);

		if ( puzzleSolve(3, S, U) ) {
			System.out.println("answer:");
			// print the elements of sequence S
			for (Object x: S) {
				System.out.print(x + " ");
			}
		}
		else {
			System.out.println("no answer");
		}
	}
}

