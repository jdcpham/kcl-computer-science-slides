package lecture1;

class FibonacciTest {
	
   public static void main(String args[]) {
	   
	  long startTime = 0;
	  long f = 0;
	  
	  startTime = System.currentTimeMillis();
	  for (int i = 0; i < 1000000; i++) {
		  f = IterativeFibonacci.iterFib( Integer.parseInt(args[0]) );
	  }
	  long elapseTime = System.currentTimeMillis() - startTime;

	  System.out.println
	     ("fib(" + args[0] + ") = " + f 
	      + " [computed iteratively in " + ((double) elapseTime)/1000000 + " ms]");
	      
	  startTime = System.currentTimeMillis();
	  for (int i = 0; i < 1000000; i++) {
		  f = RecursiveFibonacci.linearFib( Integer.parseInt(args[0]) )[0];
	  }
      elapseTime = System.currentTimeMillis() - startTime;

      System.out.println
	  ("fib(" + args[0] + ") = " + f 
	   + " [computed by linear recursion in " + ((double) elapseTime)/1000000 + " ms]");

      startTime = System.currentTimeMillis();
      f = RecursiveFibonacci.binaryFib( Integer.parseInt(args[0]) );
      elapseTime = System.currentTimeMillis() - startTime;

      System.out.println
	  ("fib(" + args[0] + ") = " + f 
	   + " [computed by binary recursion in " + elapseTime + " ms]");
    }
}
