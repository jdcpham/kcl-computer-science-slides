package lecture1;

import java.util.Scanner;

public class InputExample2 {
	
	public static void main(String args[]) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Please enter an integer: ");
		
		while (!input.hasNextInt()) {
			input.nextLine();
			System.out.print("That's not an integer; please enter an integer: ");
		}
		
		int i = input.nextInt();
		System.out.println("Thanks, I've gotten " + i);
		
		input.close();
	}
}
