package lecture1;

public class ReverseArray {
	
	public static void reverseArray(Object[] A, int i, int j) {
		if (i < j) {
			swap(A, i, j);
			reverseArray(A, i+1, j-1);
		}
	}
	
	public static void reverseArray(Object[] A) {
		reverseArray(A, 0, A.length - 1);
	}
	
	public static void iterativeReverseArray(Object[] A, int i, int j) {
		while ( i < j ) {
			swap(A, i, j);
			i++;
			j--;
		}
	}
	
	private static void swap(Object[] A, int i, int j){
		// in array A, swap the elements at positions i and j
		Object tmp = A[i];
		A[i] = A[j];
		A[j] = tmp;
	}
	
	private static void printArray(Object[] A) {
		// print the elements of array A enclosed in brackets { }
		System.out.print("{ ");
		for (Object x: A) {
			System.out.print(x+" ");
		}
		System.out.println("}");
	}
	
	// test
	public static void main(String[] args) {
		Integer[] someArray = { 2, 5, 1, 7, 11};
		printArray(someArray);
		reverseArray(someArray, 0, 4);
		printArray(someArray);
		iterativeReverseArray(someArray, 0, 4);
		printArray(someArray);
	}

}
