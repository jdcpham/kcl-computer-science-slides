/* file: IterativeFibonacci.java */

package lecture1;

public class IterativeFibonacci
{
	public static int iterFib(int n)
	{
		if (n <= 1) return n;
		else {
			int previous = 0;  // previous Fib. number (init. fib(0))
			int current = 1;   // current Fib. number  (init. fib(1))
			int next;          // next Fib. number
			for (int i = 2; i <= n; i++) {
				// current is fib(i-1); previous is fib(i-2)
				next = current + previous;  // next is fib(i)
				previous = current;      
				current = next;
				// current is fib(i); previous is fib(i-1)
			}
			return current;
		}
	}

	public static void main(String args[])
	{
		System.out.println
		("fib(" + args[0] + ") = " 
				+ iterFib(Integer.parseInt(args[0])));
	}
}

