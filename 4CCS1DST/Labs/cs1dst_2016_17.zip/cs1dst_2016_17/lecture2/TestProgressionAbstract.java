package lecture2;

public class TestProgressionAbstract {

	public static void main(String[] args) {

		ProgressionAbstract prog;
		
//		prog = new ProgressionAbstract(5); // cannot instantiate the type ProgressionAbstract
		
		// test ArithProgression2
		System.out.println("Arithmetic progression with increment 5:");
		prog = new ArithProgression2(5);
		prog.printProgression(10);
	}

}
