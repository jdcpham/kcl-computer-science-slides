package lecture2;

public interface ProgressionInterface {

	public long firstValue();  // resets the progression to the first value
	
	public long nextValue();  // advances the progression to the next value

	public void printProgression(int n); // prints the first n values of the progression

}
