package lecture2;

public interface ProgressionInterfaceJava8 {
	
	int MAX_LENGTH = 100;  // static and final -> constant
	
	public static void printMaxLength() {
		System.out.print("Maximum length of progression: " + MAX_LENGTH);
		System.out.println(); 
	}

	public long firstValue();  // resets the progression to the first value
	
	public long nextValue();  // advances the progression to the next value

	public default void printProgression(int n) { // prints the first n values of the progression

		System.out.print(firstValue());
		
		if ( n > MAX_LENGTH ) { n = MAX_LENGTH; }
		
		for (int i = 2; i <= n; i++) 
			System.out.print(" " + nextValue());
		System.out.println(); // ends the line

	}
}
