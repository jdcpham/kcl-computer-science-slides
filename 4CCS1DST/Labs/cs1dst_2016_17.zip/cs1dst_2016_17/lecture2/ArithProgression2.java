package lecture2;

public class ArithProgression2 extends ProgressionAbstract {

	/** Increment. */
	protected long inc;

	// Inherits variables first and cur.

	/** Default constructor setting a unit increment. */
	ArithProgression2() {
		this(1);
	}

	/** Parametric constructor providing the increment. */
	ArithProgression2(long increment) {
		inc = increment; 
	}

	/** Advances the progression by adding the increment to the current value.
	 * 
	 * @return next value of the progression
	 */
	protected long nextValue() {
		cur += inc;
		return cur;
	}
	
	//  Inherits methods firstValue() and printProgression(int).

}
