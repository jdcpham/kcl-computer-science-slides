package lecture2;

import net.datastructures.Node;

/**
 * singly linked list
 * 
 * insertions at head and tail; deletion at head
 * 
 */
public class SLinkedList<E> {
	protected Node<E> head;		// head node of the list
	protected Node<E> tail;		// tail (last) node of the list
	protected long size;	    // number of nodes in the list

	/** Default constructor that creates an empty list */
	public SLinkedList() {
		head = null;
		tail = null;
		size = 0;
	}

	public long size() { return size; }

	// update methods
	public void insertAtHead(E element) {
		head = new Node<E>(element, head);
		size++;
		if ( size == 1 ) {
			tail = head;
		}
	}

	public E removeAtHead() {
		if ( head != null ) {
			E elem = head.getElement();
			head = head.getNext();
			size--;
			if ( head == null ) {
				tail = null;
			}
			return elem;
		}
		else {
			return null;
		}
	}

	public void insertAtTail(E element) {
		Node<E> newNode = new Node<E>(element, null);
		if ( head != null ) {
			tail.setNext(newNode);
		}
		else {
			head = newNode;
		}
		tail = newNode;
		size++;
	}

	// create and return a String representation of the list
	// in the format: [ e1 e2 ... en ]
	public String toString() {
		String s = new String("[ ");
		Node<E> cursor = head;
		while ( cursor != null ) {
			s += cursor.getElement() + " ";
			cursor = cursor.getNext();
		}
		return ( s + "]");
	}


	public static void main(String[] args) {
		SLinkedList<Integer> list = new SLinkedList<Integer>();
		list.insertAtHead(2);
		list.insertAtHead(4);
		list.insertAtHead(null);
		list.insertAtTail(6);
		list.insertAtTail(3);
		list.insertAtTail(5);
		list.insertAtTail(7);
		System.out.println( list + " size = " + list.size());
		
		for (int i = 0; i < 8; i++) {
			System.out.println ( list.removeAtHead() + " " + list + " size = " + list.size());
		}
		
	}

}
