package lecture2;

public abstract class ProgressionAbstract {
	/** First value of the progression.  */
	protected long first;

	/** Current value of the progression.  */
	protected long cur;

	/** Default constructor.  */
	protected ProgressionAbstract() {
		cur = first = 0;
	}

	/** Resets the progression to the first value.
	 * 
	 * @return first value
	 */
	protected long firstValue() {
		cur = first;
		return cur;
	}

	/** Advances the progression to the next value.
	 *
	 * @return next value of the progression
	 */
	protected abstract long nextValue();

	/** Prints the first n values of the progression.
	 * 
	 * @param n number of values to print
	 */
	public void printProgression(int n) {
		System.out.print(firstValue());
		for (int i = 2; i <= n; i++) 
			System.out.print(" " + nextValue());
		System.out.println(); // ends the line
	}
}
