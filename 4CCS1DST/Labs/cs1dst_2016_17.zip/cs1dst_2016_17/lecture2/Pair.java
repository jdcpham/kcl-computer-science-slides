package lecture2;

public class Pair<K, V> {
  K key;
  V value;
  
  public void set(K k, V v) {
    key = k;
    value = v;
  }
  public K getKey() { return key; }
  public V getValue() { return value; }
  public String toString() {
    return "[" + getKey() + ", " + getValue() + "]";
  }
  
  public static <T> void reverse(Pair<T,T> p) {
	  p.set(p.getValue(), p.getKey());
  }
      
  public static void main (String[] args) {
	  // test the class

	  Pair<String,Integer> pair1 = new  Pair<String,Integer>();
	  System.out.println(pair1);
	  pair1.set(new String("height"), new Integer(36));
	  System.out.println(pair1);
	  pair1.set(new String("abc"), new Integer(123));
	  System.out.println(pair1);

	  Pair<String, String> pair2 = new Pair<String, String>();
	  pair2.set(new String("KCL"), new String("King's"));
	  System.out.println(pair2);   // prints: [KCL, King's]
	  reverse(pair2);
	  System.out.println(pair2);   // prints: [King's, KCL]
  }
}
