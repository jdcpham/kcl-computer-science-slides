package lecture2;

public class ArithProgressionIntFJava8 implements ProgressionInterfaceJava8 {

	/** First value of the progression.  */
	protected long first;

	/** Current value of the progression.  */
	protected long cur;
	
	/** Increment. */
	protected long inc;

	/** Default constructor setting a unit increment. */
	ArithProgressionIntFJava8() {
		this(1);
	}

	/** Parametric constructor providing the increment. */
	ArithProgressionIntFJava8(long increment) {
		inc = increment; 
	}

	/** Resets the progression to the first value.
	 * 
	 * @return first value
	 */
	public long firstValue() {
		cur = first;
		return cur;
	}

	/** Advances the progression by adding the increment to the current value.
	 * 
	 * @return next value of the progression
	 */
	public long nextValue() {
		cur += inc;
		return cur;
	}


	public static void main(String[] args) {
		ProgressionInterfaceJava8 prog;
		// test ArithProgressionIntF
		System.out.println("Arithmetic progression with default increment:");
		prog = new ArithProgressionIntFJava8();
		prog.printProgression(10);

		System.out.println("Arithmetic progression with increment 5:");
		prog = new ArithProgressionIntFJava8(5);
		prog.printProgression(10);
		
		ProgressionInterfaceJava8.printMaxLength();
		prog.printProgression(150);
	}

}
