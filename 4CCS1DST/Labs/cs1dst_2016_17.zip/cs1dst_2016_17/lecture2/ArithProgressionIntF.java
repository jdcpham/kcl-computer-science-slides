package lecture2;

public class ArithProgressionIntF implements ProgressionInterface {

	/** First value of the progression.  */
	protected long first;

	/** Current value of the progression.  */
	protected long cur;
	
	/** Increment. */
	protected long inc;

	/** Default constructor setting a unit increment. */
	ArithProgressionIntF() {
		this(1);
	}

	/** Parametric constructor providing the increment. */
	ArithProgressionIntF(long increment) {
		inc = increment; 
	}

	/** Resets the progression to the first value.
	 * 
	 * @return first value
	 */
	public long firstValue() {
		cur = first;
		return cur;
	}

	/** Advances the progression by adding the increment to the current value.
	 * 
	 * @return next value of the progression
	 */
	public long nextValue() {
		cur += inc;
		return cur;
	}

	public void printProgression(int n) {
		System.out.print(firstValue());
		for (int i = 2; i <= n; i++) 
			System.out.print(" " + nextValue());
		System.out.println(); // ends the line
	}

	public static void main(String[] args) {
		ProgressionInterface prog;
		// test ArithProgressionIntF
		System.out.println("Arithmetic progression with default increment:");
		prog = new ArithProgressionIntF();
		prog.printProgression(10);
		System.out.println("Arithmetic progression with increment 5:");
		prog = new ArithProgressionIntF(5);
		prog.printProgression(10);
	}
}
