package lecture4;

import net.datastructures.Stack;
import net.datastructures.ArrayStack;
import java.util.Arrays;
import net.datastructures.EmptyStackException;

public class StackTester {

	/** A non-recursive generic method for reversing an array */
	public static <E> void reverse(E[] a) {
		Stack<E> S = new ArrayStack<E>(a.length);
		for (int i=0; i < a.length; i++)
			S.push(a[i]);
		for (int i=0; i < a.length; i++)
			a[i] = S.pop();
	}
	
	public static <E> int popTill(Stack<E> s, E elem) {
		
		int count = 0;
		while ( (!s.isEmpty())
				&& ( ( (s.top() != null) && !(s.top().equals(elem)) )
				     || ( (s.top() == null) && (elem != null) )
				   ) ) {
			s.pop();
			count++;
		}
		return count;
	}
 
	public static void main(String[] args) {
		
		// test method reverse
		Integer[] a = {4, 8, 15, 16, 23, 42};  // auto-boxing allows this
		String[] s = {"Jack", "Kate", "Hurley", "Jin", "Boone"};
		System.out.println("a = " + Arrays.toString(a));
		System.out.println("s = " + Arrays.toString(s));
		System.out.println("Reversing...");
		reverse(a);
		reverse(s);
		System.out.println("a = " + Arrays.toString(a));
		System.out.println("s = " + Arrays.toString(s));
		
		// test method popTill
		Stack<Integer> st = new ArrayStack<Integer>();
		st.push(5); st.push(null); st.push(7); st.push(3); st.push(null); st.push(9);
		System.out.println("stack st: 5, null, 7, 3, null, 9(top);  stack size: " + st.size());
		popTill(st, 3);
		System.out.println("popTill(st, 3); stack size: " + st.size());
		popTill(st, 3);
		System.out.println("popTill(st, 3); stack size: " + st.size());
		popTill(st, null);
		System.out.println("popTill(st, null); stack size: " + st.size());
		popTill(st, 3);
		System.out.println("popTill(st, 3); stack size: " + st.size());
		
		if (!st.isEmpty()) {
			System.out.println("top of stack: " + st.top());
		}
		else {
			System.out.println("stack st is empty");
		}
		
		try {
			System.out.println("top of stack: " + st.top());
		} catch (EmptyStackException ex)
        {
			System.out.println("stack st is empty");
        }
	}

}
