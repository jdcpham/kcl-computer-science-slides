package labsSGTsCoursework.lab5;

/** iterative merge sort */
public class MergeSort
{
	/** sort the elements a[0 : a.length - 1] using
	 * the merge sort method */
	public static <T extends Comparable<T>> void mergeSort(T[] a)
	{
		mergeSort(a, 0, a.length - 1);
	}

	private static <T extends Comparable<T>> void mergeSort( T[] a, int left, int right )
	{
		if ( left < right ) {
			int middle = (left + right) / 2;
			mergeSort(a, left, middle);
			mergeSort(a, middle + 1, right);

			// a[left, ..., middle] and a[middle+1, ..., right] are sorted
			merge(a, left, middle, right);
		}
	}

	/** merge adjacent segments in a */
	private static <T extends Comparable<T>> void merge(T[] a, int left, int middle, int right) {
		T[] b = (T[]) new Comparable [a.length];		

		int i = left;              // current position in the first segment
		int j = middle + 1;  // current position in the second segment
		int k = 0;                // current position in array b

		// merge until one segment is done
		while ( (i <= middle) && (j <= right) )
			if ( a[i].compareTo( a[j]) <= 0 )
				b[k++] = a[i++];
			else
				b[k++] = a[j++];

		// copy the remaining elements from the first segment to array b
		while ( i <= middle )  b[k++] = a[i++];

		// copy the elements from array b back to array a
		while ( k > 0 )  a[--j] = b[--k];
	}
	
	public static void main(String args[]) {
		String[] a = {"aa", "bc", "ac", "bbb"};
		for (String s: a) System.out.print(s + " ");
		System.out.println();
		
		mergeSort(a);
		for (String s: a) System.out.print(s + " ");
		System.out.println();
		
		Integer[] b = { 12, 7, 5, 9 };
		for (Integer i: b) System.out.print(i + " ");
		System.out.println();
		
		mergeSort(b);
		for (Integer i: b) System.out.print(i + " ");
		System.out.println();	
	}
}

