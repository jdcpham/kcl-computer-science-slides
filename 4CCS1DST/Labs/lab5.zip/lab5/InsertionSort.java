package labsSGTsCoursework.lab5;

public class InsertionSort {

	/** 
	 * 
	 * sort the array a using the insertion sort method;
	 * the argument is an array of elements of type T,
	 * where T is a generic type which implements interface Comparable<T>;
	 * this means that the actual type can be any class which includes 
	 * method compareTofior example, String, Integer, or any class X which 
	 * implements the interface Comparable<X>;
	 * 
	 * */
	public static <T extends Comparable<T>> void insertionSort(T[] a) {
		for (int i = 1; i < a.length; i++) {  
			// insert a[i] into a[0:i-1]
			T t = a[i];

			// find proper place for t
			int j;
			for (j = i - 1; ( j >= 0 && t.compareTo(a[j]) < 0 ); j--)
				a[j+1] = a[j];

			a[j+1] = t;  // insert t = original a[i]
		}
	}
	
	public static void main(String args[]) {
		String[] a = {"aa", "bc", "ac", "bbb"};
		for (String s: a) System.out.print(s + " ");
		System.out.println();
		
		insertionSort(a);
		for (String s: a) System.out.print(s + " ");
		System.out.println();
		
		Integer[] b = { 12, 7, 5, 9 };
		for (Integer i: b) System.out.print(i + " ");
		System.out.println();
		
		insertionSort(b);
		for (Integer i: b) System.out.print(i + " ");
		System.out.println();	
	}

}
