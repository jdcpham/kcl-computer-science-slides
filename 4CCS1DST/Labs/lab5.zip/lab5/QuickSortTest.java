package labsSGTsCoursework.lab5;

public class QuickSortTest {

	public static void main(String [] args) {
		// create an array for n objects of type Integer,
		// where n is the argument given in the command line
		int n=Integer.parseInt(args[0]);
		Integer [] a = new Integer[n];

		// fill in the array with values 1,2,3, ..., in reverse order
		for (int i = 0; i < n; i++) {
			a[i] = new Integer(n-i);
		}

		// print out the elements of the array
		System.out.print("Elements in unsorted array: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}
		System.out.println();

		// sort the elements
		QuickSort.quickSort(a);

		// print out the elements of the array
		System.out.print("Elements in sorted array: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}
		System.out.println();
	}
}
