package labsSGTsCoursework.lab5;

/** quick sort */
public class QuickSort
{
   /** sort a[0 : a.length - 1] using the quick sort method */
   public static <T extends Comparable<T>> void quickSort(T[] a)
   {
      if (a.length <= 1) return;
      quickSort(a, 0, a.length - 1);
   }
   
   /** sort a[leftEnd:rightEnd], a[rightEnd+1] >= a[leftEnd:rightEnd] */
   private static <T extends Comparable<T>> void quickSort(T[] a, int leftEnd, int rightEnd)
   {
      if (leftEnd >= rightEnd) return;

      int leftCursor = leftEnd;        // left-to-right cursor
      int rightCursor = rightEnd-1;    // right-to-left cursor
      T pivot = a[rightEnd];
   
      // swap elements >= pivot on left side
      // with elements <= pivot on right side
      while (leftCursor<=rightCursor)
      {
    	  while ((leftCursor<=rightCursor) && (a[leftCursor].compareTo(pivot) <= 0))
    	    leftCursor++;
    	  while ((leftCursor<=rightCursor) &&(a[rightCursor].compareTo(pivot) >= 0))
      	    rightCursor--;
      	  
    	  if (leftCursor >= rightCursor) break;  // swap pair not found
   		  T temp=a[leftCursor]; 
          a[leftCursor]=a[rightCursor];
          a[rightCursor]=temp;
     
      }
      // place pivot
      a[rightEnd] = a[leftCursor];
      a[leftCursor] = pivot;
   
      quickSort(a, leftEnd, leftCursor-1);   // sort left segment
      quickSort(a, leftCursor + 1, rightEnd);  // sort right segment
   }
   
	public static void main(String args[]) {
		String[] a = {"aa", "bc", "ac", "bbb"};
		for (String s: a) System.out.print(s + " ");
		System.out.println();
		
		quickSort(a);
		for (String s: a) System.out.print(s + " ");
		System.out.println();
		
		Integer[] b = { 12, 7, 5, 9 };
		for (Integer i: b) System.out.print(i + " ");
		System.out.println();
		
		quickSort(b);
		for (Integer i: b) System.out.print(i + " ");
		System.out.println();	
	}   
}
