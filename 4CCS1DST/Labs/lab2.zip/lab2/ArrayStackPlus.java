package labsSGTsCoursework.lab2;

import net.datastructures.ArrayStack;
import net.datastructures.EmptyStackException;

public class ArrayStackPlus<E> extends ArrayStack<E> implements StackPlus<E> {
	
	public ArrayStackPlus(int cap) {
		super(cap);
	}

	public ArrayStackPlus() {
		super();
	}

	public E popFirstNotNull() throws EmptyStackException {
		
		while ( (top >= 0) && ( S[top] == null ) ) {
			top--;
		}
		if ( top >= 0 ) {
			// we've reached a non-null element;
			// remove this element from the stack
			// and return it;
			E topNonNull = S[top];
			S[top--] = null;
			return topNonNull;
		}
		else {
			// the stack has been empty, or it has had only null elements
			// and all those null elements have been removed;
			// no element to return, so we throw an exception;
			throw new EmptyStackException("Stack had only null elements.");
		}
	}


	public static void main(String[] args) {
		// test method popFirstNotNull();

		// create an interesting test stack;
		StackPlus<String> S = new ArrayStackPlus<String>(20);		
		S.push(null); S.push(null); 
		S.push("abc");  
		S.push(null); S.push(null);  
		S.push("def");  
		S.push("ghi");
		S.push(null); S.push(null); S.push(null);
		S.push("xyz"); 
		
		System.out.println("stack S: " + S);
				// prints: "stack S: [null, null, abc, null, null, def, ghi, null, null, null, xyz]"
		
		// the following loop will remove four not-null elements (in the first four iterations), 
		// and then, in the 5-th iteration, it will throw an exception while trying to remove 
		// a not-null element from the stack which contains only null elements;
		
		try {
			for (int i = 0; i < 10; i++) {
				System.out.println("pop first not-null");
				String str = S.popFirstNotNull();
				System.out.println("removed element: " + str);
				System.out.println("stack S: " + S);
			}	
		}
		catch (EmptyStackException e) {
			System.out.println(e);
			System.out.println("stack S: " + S);
		}

	}
}

