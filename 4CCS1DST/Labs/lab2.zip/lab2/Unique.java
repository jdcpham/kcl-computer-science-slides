package labsSGTsCoursework.lab2;

import java.util.Arrays;

public class Unique {

	public static boolean isUniqueLoop(int[] arr, int start, int end) {
		for ( int i = start; i < end; i++ )
			for ( int j = i+1; j <= end; j++ )
				if ( arr[i] == arr[j] )
					return false;     // the same  element at locations i and j
		// all elements are unique   
		return true;  
	}

	public static boolean isUniqueSorting(int[] arr, int start, int end) {
		// (Question 1.c)
		// Check the uniqueness of the elements in the array by first sorting them
		
		// We're assuming that the order of the elements in the array arr shouldn't be 
		// changed, so we need a temporary copy of the relevant part of array arr.

		int[] tempArr = Arrays.copyOfRange(arr, start, end + 1);

		// sort the array tempArr
		Arrays.sort(tempArr);

		// compare the pairs of consecutive elements in the sorted array tempArr
		for ( int i = 0; i < tempArr.length - 1; i++ ) {
			if ( tempArr[i] == tempArr[i+1] ) {
				// the same  element at locations i and i+1
				return false;     
			}
		}
		
		// all elements are unique   
		return true;  
	}


	public static void main(String [] args) {
		// small tests of the method isUniqueLoop (Question 1.a)
		int[] A = { 4, 9, 3, 7, 5, 4, 7 };
		System.out.print("array:");
		for (int i = 0; i < A.length; i++) {
			System.out.print(" " + A[i]);
		}
		System.out.println();
		System.out.println("isUniqueLoop(A, 0, 6): " + isUniqueLoop(A, 0, 6) );
		System.out.println("isUniqueLoop(A, 0, 4): " + isUniqueLoop(A, 0, 4) );
		System.out.println("isUniqueLoop(A, 2, 6): " + isUniqueLoop(A, 2, 6) );

		// observing actual running times of the method isUniqueLoop for longer arrays (Question 1.b)
		int arrayLength = 400000;	// the length of the array
		long startTime, elapseTime; // to record the actual running times
		boolean areUnique;			// to record the outcome of the Uniqueness methods

		// create an array of unique numbers
		int[] a = new int[arrayLength];
		for (int i = 0; i < a.length; i++) {
			a[i] = i;
		}

		// n = arrayLength/4
		
		for (int n = arrayLength/4; n <= arrayLength; n *= 2) {
			startTime = System.currentTimeMillis();
			areUnique = isUniqueLoop(a,0,n-1);
			elapseTime = System.currentTimeMillis() - startTime;
			System.out.println("All numbers are distinct: " + areUnique 
					+ " [" + n + " numbers, method isUniqueLoop, " +  elapseTime + " ms]");
		}
		
		// we now test the method isUniqueLoop on a large array with two elements the same;
		// make the last and the 3rd-last elements the same;
		a[arrayLength-3] = a[arrayLength-1];
		startTime = System.currentTimeMillis();
		areUnique = isUniqueLoop(a,0,arrayLength-1);
		elapseTime = System.currentTimeMillis() - startTime;
		System.out.println("All numbers are distinct: " + areUnique 
				+ " [" + arrayLength + " numbers, method isUniqueLoop, " +  elapseTime + " ms]");

		// test method isUniqueSorting (Question 1.c)
		// first tests on the short array A
		System.out.print("array:");
		for (int i = 0; i < A.length; i++) {
			System.out.print(" " + A[i]);
		}
		System.out.println();
		System.out.println("isUniqueSorting(A, 0, 6): " + isUniqueSorting(A, 0, 6) );
		System.out.println("isUniqueSorting(A, 0, 4): " + isUniqueSorting(A, 0, 4) );
		System.out.println("isUniqueSorting(A, 2, 6): " + isUniqueSorting(A, 2, 6) );

		// now we observe actual running times of the method isUniqueSorting on longer arrays (Question 1.c)

		arrayLength = 1000000;
		int[] a2 = new int[arrayLength];
		for (int i = 0; i < a2.length; i++) {
			a2[i] = i;
		}

		for (int n = arrayLength/4; n <= arrayLength; n *= 2) {
			startTime = System.currentTimeMillis();
			areUnique = isUniqueSorting(a2,0,n-1);
			elapseTime = System.currentTimeMillis() - startTime;
			System.out.println("All numbers are distinct: " + areUnique 
					+ " [" + n + " numbers, method isUniqueSorting, " +  elapseTime + " ms]");
		}

		a2[arrayLength-3] = a2[arrayLength-1];
		startTime = System.currentTimeMillis();
		areUnique = isUniqueSorting(a2,0,arrayLength-1);
		elapseTime = System.currentTimeMillis() - startTime;
		System.out.println("All numbers are distinct: " + areUnique 
				+ " [" + arrayLength + " numbers, method isUniqueSorting, " +  elapseTime + " ms]");

	}

}
