package labsSGTsCoursework.lab2;

import net.datastructures.EmptyStackException;
import net.datastructures.Stack;

public interface StackPlus<E> extends Stack<E> {
	
	 /** 
	  * Remove the first non-null element from the top of the stack.
	  * If there is one or more null elements on the top of the stack,
	  * then all of them should be removed first, and then the first non-null
	  * element should be removed and returned.
	  * 
	  * If the stack is empty, then an exception of type EmptyStackException 
	  * should be thrown.
	  * 
	  * If the stack is not empty, but contains only null elements, then all
	  * these elements should be removed and then an exception of type 
	  * EmptyStackException should be thrown.
	  */
	  public E popFirstNotNull() throws EmptyStackException; 
	 
}
