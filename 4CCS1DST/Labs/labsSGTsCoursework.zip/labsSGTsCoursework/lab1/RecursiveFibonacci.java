package labsSGTsCoursework.lab1;

import lecture2.Pair;

class RecursiveFibonacci {

	//the binaryFib method doesn't change
	public static int binaryFib(int n) {
		if (n <= 1) return n;
		else return binaryFib(n-1) + binaryFib(n-2);
	}

	// method linearFib, instead of using arrays of length two,
	// now uses objects of type Pair<Integer, Integer>;
	// a call linerFib(n) returns a pair with the key and the value 
	// equal to the n-th and (n-1)-st Fibonacci numbers, respectively;

	public static Pair<Integer,Integer> linearFib(int n) {
		Pair<Integer, Integer> F;
		if (n <= 1) {
			F = new Pair<Integer, Integer>();
			F.set(new Integer(n), new Integer(0));
		}
		else { 
			F = linearFib(n-1);
			F.set(new Integer(F.getKey() + F.getValue()), F.getKey());
		}
		return F;
	}

	public static void main(String args[]) {
		System.out.println("fib(8) = " + binaryFib(8));
		System.out.println("fib(8) = " + linearFib(8).getKey());

		System.out.println("fib(" + args[0] + ") = " + binaryFib(Integer.parseInt(args[0])));
		System.out.println("fib(" + args[0] + ") = " + linearFib(Integer.parseInt(args[0])).getKey());
	}
}
