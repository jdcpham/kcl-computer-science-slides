package labsSGTsCoursework.lab1;

class RecursiveFactorial {
	
   public static int factorial(int n) {
      if(n <= 1) return 1;
      else return n * factorial(n-1);
   }

   public static void main(String args[]) {
       if ( args.length < 1 )
    	   System.out.println("5! is equal to " + factorial(5));
       else
    	   System.out.println(args[0]+ "! is equal to "  + factorial(Integer.parseInt(args[0])));
   }
}
