package labsSGTsCoursework.lab1;

public class Pair<K, V> {
  K key;
  V value;
  
  public Pair(K k, V v) {
	  key = k;
	  value = v;
  }

  public Pair() {
	  this(null,null);
  }

  public void set(K k, V v) {
    key = k;
    value = v;
  }
  public K getKey() { return key; }
  public V getValue() { return value; }
  
  public String toString() {
    return "[" + getKey() + ", " + getValue() + "]";
  }
  
  public static <T> void reverse(Pair<T,T> p) {
	  p.set(p.getValue(), p.getKey());
  }
      
  public boolean equals(Object otherPair) {
	  
	  // "not equal", if otherPair is null
	  if ( otherPair == null ) { return false; }
	  
	  // "not equal", if objects of different classes
	  if ( getClass() != otherPair.getClass() ) { return false; }
	  
	  // "not equal", if the keys not equal or the values not equal,
	  // but to access the key and value in the object otherPair, we first
	  // have to cast it to type Pair<K,V>
	  Pair<K,V> x = (Pair<K,V>) otherPair;
	  if ( getKey() == null && x.getKey() != null ) { return false; }
	  if ( (getKey() != null) && (!getKey().equals(x.getKey())) ) { return false; }
	  if ( getValue() == null && x.getValue() != null ) { return false; }
	  if ( (getValue() != null) && (!getValue().equals(x.getValue())) ) { return false; }
	  
	  // otherwise "equal"
	  return true;
  }

  public static void main (String[] args) {
	  // test the class

	  Pair<String,Integer> pair1 = new  Pair<String,Integer>("height", 36);
	  System.out.println(pair1);
	  pair1.set("abc", 123);
	  System.out.println(pair1);

	  Pair<String, String> pair2 = new Pair<String, String>("KCL", "King's");
	  System.out.println(pair2);   // prints: [KCL, King's]
	  reverse(pair2);
	  System.out.println(pair2);   // prints: [King's, KCL]
	  
	  Pair<String, Integer> pairA = new Pair<String, Integer>("abc", 1);
	  Pair<String, Integer> pairAA = pairA;
	  Pair<String, Integer> pairB = new Pair<String, Integer>("abc", 2);
	  Pair<String, Integer> pairC = new Pair<String, Integer>("xyz", 1);
	  Pair<String, Integer> pairD = new Pair<String, Integer>("abc", 1);
	  Pair<String, Integer> pairE = new Pair<String, Integer>();
	  Pair<String, Integer> pairF = new Pair<String, Integer>(null, 1);
	  Pair<String, Integer> pairG = null;

	  System.out.println( pairA.equals(pairAA) );
	  System.out.println( pairA.equals(pairB) );
	  System.out.println( pairA.equals(pairC) );
	  System.out.println( pairA.equals(pairD) );
	  System.out.println( pairA.equals(null) );
	  System.out.println( pairA.equals(5) );
	  System.out.println( pairE.equals(pairA) );
	  System.out.println( pairF.equals(pairA) );
	  System.out.println( pairA.equals(pairG) );
	  
	  System.out.println( "\"abc\" == \"abc\": " + ("abc" == "abc") );
	  System.out.println( "1 == 1: " + (1 == 1) );
	  System.out.println( "Integer(1) == Integer(1): " + ((new Integer(1)) == (new Integer(1))) );
	  System.out.println( "Integer(1).equals(Integer(1)): " + ((new Integer(1)).equals(new Integer(1))) );
	  System.out.println( "\"abc\" == \"abc\": " + ((new String("abc")).equals(new String("abc"))) );

  }
}
