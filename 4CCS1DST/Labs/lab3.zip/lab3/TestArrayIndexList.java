package labsSGTsCoursework.lab3;

import net.datastructures.IndexList;
import net.datastructures.ArrayIndexList;

public class TestArrayIndexList {

	public static void main(String[] args) {

		IndexList<String> a = new ArrayIndexList<String>();

		// insert to list "a" the given words with the specified indices;
		// the words and indices are in the array args;

		int j = 0;
		while ( j < args.length - 1 ) {
			// add to the list the string args[j] at index args[j+1]; 
			int index = Integer.parseInt(args[j+1]);
			
			if ( (index < 0) || (index > a.size()) ) {
				System.out.println("index out of bounds: size = " + a.size() + "; index = " + index);
			}
			else {
				a.add(index, args[j]);
			}
			
			j = j + 2;
		}
		
		// show the elements of the list
		System.out.println("the list has " + a.size() + " elements:");
		for (int i = 0; i < a.size(); i++) {
			System.out.print(a.get(i) + " ");
		}

	}

}
