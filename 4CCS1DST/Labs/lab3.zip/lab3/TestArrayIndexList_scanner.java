package labsSGTsCoursework.lab3;

import java.util.Scanner;
import net.datastructures.IndexList;
import net.datastructures.ArrayIndexList;

public class TestArrayIndexList_scanner {

	public static void main(String[] args) {

		// test for the Index List
		IndexList<String> a = new ArrayIndexList<String>();
		
		System.out.println("give words and their indices in the list:");
		Scanner input = new Scanner(System.in);

		while ( input.hasNext() ) {
			String s = input.next();  // the string to be added to the list
			if ( input.hasNextInt() ) {
				int index = input.nextInt(); // the index where the new element will be added
				
				if ( (index < 0) || (index > a.size()) ) {
					System.out.println("index out of bounds: size = " + a.size() + "; index = " + index);
				}
				else {
					a.add(index, s);
				}
			}
		}
		input.close();

		// show the elements of the list
		System.out.println("the list has " + a.size() + " elements:");
		for (int i = 0; i < a.size(); i++) {
			System.out.print(a.get(i) + " ");
		}
	}

}
