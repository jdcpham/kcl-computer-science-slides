package labsSGTsCoursework.lab3;

import net.datastructures.Position;
import net.datastructures.PositionList;
import net.datastructures.NodePositionList;
import net.datastructures.DNode;

public class NodePositionListExtended<E> extends NodePositionList<E> {
	
	// remove all elements from the otherList, one by one, 
	// and add them at the end of this list;
	// the running time is linear in the number of elements of the otherList;
	public void append1(PositionList<E> otherList) {
		while ( !otherList.isEmpty() ) {
			addLast(otherList.remove(otherList.first()));
		}
	}
	
	// append the otherList to the end of this list;
	// the otherList becomes empty;
	// this method runs in constant time;
	public void append2(NodePositionListExtended<E> otherList) {
		
		// link the last node of this list with 
		// the first node of the otherList
		this.trailer.getPrev().setNext(otherList.header.getNext());
		otherList.header.getNext().setPrev(this.trailer.getPrev());
		
		// the trailer of the otherList has become the trailer of this list;
		// the otherList takes the trailer from this list;
		otherList.header.setNext(this.trailer);
		this.trailer.setPrev(otherList.header);
		
		// swap trailers
		DNode<E> temp = this.trailer;
		this.trailer = otherList.trailer;
		otherList.trailer = temp;
		
		// update the sizes of the lists;
		this.numElts += otherList.numElts;
		otherList.numElts = 0;
	}
	
	public Position<E> lastOccurrence(E e) {
		
		// start from the last node and keep moving 
		// towards the beginning of the list
		DNode<E> x = trailer.getPrev();
		
		// if the header hasn't been reached yet and
		// the element at the current node x isn't equal to
		// the search element e, then move to the previous node;
		// make sure that you cover the case that the element at the current 
		// node is null, and the case that the query element is null;
		// the condition of the while loop below should work, but other
		// conditions may work as well;
		while ( (x != header) 
				&& ( ( (x.element() == null ) && (e !=null) )
					|| ( (x.element() != null ) && ( !x.element().equals(e) ) ) ) ) {
			x = x.getPrev();
		}
		if (x != header) {
			return x;
		}
		else {
			return null;
		}
	}
	
	public static void main(String[] args) {
		
		NodePositionListExtended<Integer> list1 = new NodePositionListExtended<Integer>();
		list1.addLast(3);
		list1.addLast(7);
		list1.addLast(4);
		
		NodePositionListExtended<Integer> list2 = new NodePositionListExtended<Integer>();
		list2.addLast(2);
		list2.addLast(7);
		list2.addLast(5);
		
		// test append1 and append2;
		System.out.println(list1); // prints: "[3, 7, 4]"
		System.out.println(list2); // prints: "[2, 7, 5]"

		list1.append2(list2);  // replace with append2 to test append2
		
		System.out.println(list1 + "; size = " + list1.size()); // prints: "[3, 7, 4, 2, 7, 5]; size = 6"
		System.out.println(list2 + "; size = " + list2.size());	// prints: "[]; size = 0"
		
		// test lastOccurrence
		System.out.print( "the element before the last occurrence of 7: ");
		Position<Integer> p = list1.lastOccurrence(7);
		System.out.println( (p == null || (p == list1.first()) )? null : list1.prev(p).element() );
		
		System.out.print( "the element before the last occurrence of 3: ");
		p = list1.lastOccurrence(3);
		System.out.println( (p == null || (p == list1.first()))? null : list1.prev(p).element() );
		
		list1.addFirst(null);
		list1.addLast(null);
		System.out.println(list1 + "; size = " + list1.size()); 
			// prints: "[null, 3, 7, 4, 2, 7, 5, null]; size = 6"
		System.out.print( "the element before the last occurrence of null: ");
		p = list1.lastOccurrence(null);
		System.out.println( (p == null || (p == list1.first()))? null : list1.prev(p).element() );	
	}
}
