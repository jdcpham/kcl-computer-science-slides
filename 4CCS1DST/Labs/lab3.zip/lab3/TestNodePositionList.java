package labsSGTsCoursework.lab3;

import net.datastructures.PositionList;
import net.datastructures.NodePositionList;
import net.datastructures.Position;

public class TestNodePositionList {

	public static void main(String[] args) {

		// test for the Position List

		PositionList<String> nList = new NodePositionList<String>();

		int j = 0;
		while ( j < args.length - 1 ) {
			// add to the list the string args[j];
			// args[j+1], which should be "first" or "last" indicates where
			// the string args[j] should be added in the list; 
			if ( args[j+1].equals("first") ) {
				nList.addFirst(args[j]);
			}
			else if ( args[j+1].equals("last") ) {
				nList.addLast(args[j]);
			}
			else {
				System.out.println("invalid position: " + args[j+1]);
			}
			
			j = j + 2;
		}

		// show the elements of the list;
		System.out.println("the list has " + nList.size() + " elements:");
		// starting from the first position in the list,
		// go over the list using the method next(p); 
		if ( !nList.isEmpty() ) {
			Position<String> p = nList.first();
			System.out.print(p.element() + " ");
			while ( p != nList.last() ) {
				p = nList.next(p);
				System.out.print(p.element() + " ");
			}
		}
		System.out.println();
		
		// alternatively, we can  access all elements of the list in order 
		// using the fact that PositionList is Iterable
		for (String s: nList) {
			System.out.print(s + " ");
		}
	}

}
